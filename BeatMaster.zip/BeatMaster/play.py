import pyttsx3
import speech_recognition as sr
import datetime
import wikipedia
import webbrowser
import os


engine = pyttsx3.init('sapi5')
voices = engine.getProperty('voices')
engine.setProperty('voice',voices[0].id)

def greeTing():
    hour = int(datetime.datetime.now().hour)
    if hour>=0 and hour<12:
        speak("Good Morning")
    elif hour>=12 and hour<18:
        speak("Good Afternoon")
    else:
        speak("Good Evening")
    speak("I am Beatmaster, How can I help you?")

def speak(audio):
    engine.say(audio)
    engine.runAndWait()

'''It takes micrphone input from the user and returns string output'''
def takeCommand():
    r = sr.Recognizer()
    with sr.Microphone() as source:
        print("listening............")
        r.pause_threshold = 1 
        audio = r.listen(source)
    try: 
        print("Recognizing....")
        query = r.recognize_google(audio, language='en-in')
        print(f"User Said: {query}\n")
    except Exception as e:
        print("Say that again please....")
        return "None"
    return query

if __name__ == "__main__":
   greeTing()
   while True:
       query = takeCommand().lower()
# Logic for executing task based on query
       if'open youtube' in query:
         speak("opening youtube for you")
         webbrowser.open("youtube.com")

       elif 'play music' in query:
         music_dir = 'C://Users//dheer//OneDrive//Documents//Audio'
         songs = os.listdir(music_dir)
         print(songs)
         speak("playing music for you sir enjoy")
         os.startfile(os.path.join(music_dir, songs[0]))

       elif 'play lofi' in query:
         music_dir = 'C://Users//dheer//OneDrive//Desktop//BeatMaster//play lofi'
         songs = os.listdir(music_dir)
         print(songs)
         speak("playing music for you sir enjoy")
         os.startfile(os.path.join(music_dir, songs[0]))

       elif 'play anime song' in query:
         music_dir = 'C://Users//dheer//OneDrive//Desktop//BeatMaster//play Anime Song'
         songs = os.listdir(music_dir)
         print(songs)
         speak("playing music for you sir enjoy")
         os.startfile(os.path.join(music_dir, songs[0]))

       elif 'the beat' in query:
         music_dir = 'C://Users//dheer//OneDrive//Desktop//BeatMaster//play Phonk'
         songs = os.listdir(music_dir)
         print(songs)
         speak("playing music for you sir enjoy")
         os.startfile(os.path.join(music_dir, songs[0]))

       elif 'quit' in query:
          speak("Bye sir, I hope you had a quality time with me, see you again!")
          exit()

    

    

   
  